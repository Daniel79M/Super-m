<header class="app-bar">
    <table width="100%">
        <tr>
            <td>
                <a href="{{ route('home') }}">
                    <b>Home</b>
                </a>
            </td>
            <td class="text-right">
                <a href="">
                    <b>Paramètres</b>
                </a>
            </td>
        </tr>
    </table>
</header>